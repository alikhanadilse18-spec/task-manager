from __future__ import annotations

import os
from datetime import date
from typing import Any

import psycopg
from flask import Flask, g, jsonify, request
from psycopg.rows import dict_row

app = Flask(__name__)
PRIORITIES = {"low", "medium", "high"}
TASK_COLUMNS = """
    id, title, details, priority, category, due_date,
    completed, created_at, updated_at
"""


def get_db() -> psycopg.Connection[Any]:
    if "db" not in g:
        database_url = os.environ.get("DATABASE_URL")
        if not database_url:
            raise RuntimeError("DATABASE_URL is not configured.")
        g.db = psycopg.connect(database_url, row_factory=dict_row)
    return g.db


@app.teardown_appcontext
def close_db(_error: BaseException | None) -> None:
    connection = g.pop("db", None)
    if connection is not None:
        connection.close()


def serialize_task(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": row["id"],
        "title": row["title"],
        "details": row["details"],
        "priority": row["priority"],
        "category": row["category"],
        "dueDate": row["due_date"].isoformat() if row["due_date"] else None,
        "completed": row["completed"],
        "createdAt": row["created_at"].isoformat(),
        "updatedAt": row["updated_at"].isoformat(),
    }


def validate_task_fields(
    body: dict[str, Any], *, partial: bool
) -> tuple[dict[str, Any] | None, str | None]:
    allowed = {"title", "details", "priority", "category", "dueDate", "completed"}
    unknown = set(body) - allowed
    if unknown:
        return None, "Запрос содержит неизвестные поля."

    if not partial or "title" in body:
        title = body.get("title")
        if not isinstance(title, str) or not title.strip():
            return None, "Введите название задачи."
        if len(title.strip()) > 180:
            return None, "Название не должно превышать 180 символов."
        body["title"] = title.strip()

    if not partial:
        body.setdefault("details", None)
        body.setdefault("priority", "medium")
        body.setdefault("category", None)
        body.setdefault("dueDate", None)

    if "details" in body:
        details = body["details"]
        if details is not None and not isinstance(details, str):
            return None, "Описание должно быть текстом."
        if isinstance(details, str):
            details = details.strip() or None
            if details and len(details) > 2000:
                return None, "Описание не должно превышать 2000 символов."
            body["details"] = details

    if "priority" in body:
        if body["priority"] not in PRIORITIES:
            return None, "Укажите допустимый приоритет задачи."

    if "category" in body:
        category = body["category"]
        if category is not None and not isinstance(category, str):
            return None, "Категория должна быть текстом."
        if isinstance(category, str):
            category = category.strip() or None
            if category and len(category) > 60:
                return None, "Категория не должна превышать 60 символов."
            body["category"] = category

    if "dueDate" in body:
        due_date = body["dueDate"]
        if due_date is not None:
            if not isinstance(due_date, str):
                return None, "Укажите корректную дату."
            try:
                date.fromisoformat(due_date)
            except ValueError:
                return None, "Укажите корректную дату."

    if "completed" in body and not isinstance(body["completed"], bool):
        return None, "Статус выполнения должен быть логическим значением."

    return body, None


@app.get("/healthz")
def health_check():
    return jsonify({"status": "ok"})


@app.get("/tasks")
def list_tasks():
    status = request.args.get("status", "all")
    priority = request.args.get("priority")
    search = request.args.get("search", "").strip()
    if status not in {"all", "open", "completed", "overdue"}:
        return jsonify({"error": "Неизвестный фильтр задач."}), 400
    if priority and priority not in PRIORITIES:
        return jsonify({"error": "Неизвестный приоритет."}), 400

    clauses: list[str] = []
    values: list[Any] = []
    if status == "open":
        clauses.append("completed = %s")
        values.append(False)
    elif status == "completed":
        clauses.append("completed = %s")
        values.append(True)
    elif status == "overdue":
        clauses.append("completed = %s AND due_date < CURRENT_DATE")
        values.append(False)
    if priority:
        clauses.append("priority = %s")
        values.append(priority)
    if search:
        clauses.append("(title ILIKE %s OR COALESCE(details, '') ILIKE %s)")
        values.extend([f"%{search}%", f"%{search}%"])

    where_clause = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    rows = get_db().execute(
        f"""
        SELECT {TASK_COLUMNS}
        FROM tasks
        {where_clause}
        ORDER BY completed ASC, due_date ASC NULLS LAST,
                 CASE priority WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
                 created_at DESC
        """,
        values,
    ).fetchall()
    return jsonify([serialize_task(row) for row in rows])


@app.get("/tasks/summary")
def get_task_summary():
    row = get_db().execute(
        """
        SELECT
            COUNT(*)::int AS total,
            COUNT(*) FILTER (WHERE NOT completed)::int AS open,
            COUNT(*) FILTER (WHERE completed)::int AS completed,
            COUNT(*) FILTER (
                WHERE NOT completed AND due_date < CURRENT_DATE
            )::int AS overdue,
            COUNT(*) FILTER (
                WHERE NOT completed AND due_date = CURRENT_DATE
            )::int AS "dueToday"
        FROM tasks
        """
    ).fetchone()
    return jsonify(row)


@app.post("/tasks")
def create_task():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({"error": "Ожидаются данные задачи в формате JSON."}), 400
    values, error = validate_task_fields(payload, partial=False)
    if error:
        return jsonify({"error": error}), 400

    with get_db().transaction():
        row = get_db().execute(
            f"""
            INSERT INTO tasks (title, details, priority, category, due_date)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING {TASK_COLUMNS}
            """,
            (
                values["title"],
                values["details"],
                values["priority"],
                values["category"],
                values["dueDate"],
            ),
        ).fetchone()
    return jsonify(serialize_task(row)), 201


@app.patch("/tasks/<int:task_id>")
def update_task(task_id: int):
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict) or not payload:
        return jsonify({"error": "Передайте поля, которые нужно изменить."}), 400
    values, error = validate_task_fields(payload, partial=True)
    if error:
        return jsonify({"error": error}), 400

    column_names = {
        "title": "title",
        "details": "details",
        "priority": "priority",
        "category": "category",
        "dueDate": "due_date",
        "completed": "completed",
    }
    fields = list(values.keys())
    assignments = [f"{column_names[field]} = %s" for field in fields]
    assignments.append("updated_at = CURRENT_TIMESTAMP")
    params = [
        values[field] for field in fields
    ]
    params.append(task_id)

    with get_db().transaction():
        row = get_db().execute(
            f"""
            UPDATE tasks
            SET {", ".join(assignments)}
            WHERE id = %s
            RETURNING {TASK_COLUMNS}
            """,
            params,
        ).fetchone()
    if row is None:
        return jsonify({"error": "Задача не найдена."}), 404
    return jsonify(serialize_task(row))


@app.delete("/tasks/<int:task_id>")
def delete_task(task_id: int):
    with get_db().transaction():
        result = get_db().execute(
            "DELETE FROM tasks WHERE id = %s",
            (task_id,),
        )
    if result.rowcount == 0:
        return jsonify({"error": "Задача не найдена."}), 404
    return "", 204


if __name__ == "__main__":
    app.run(
        host="127.0.0.1",
        port=int(os.environ.get("PORT", "5001")),
        debug=False,
        threaded=True,
    )
