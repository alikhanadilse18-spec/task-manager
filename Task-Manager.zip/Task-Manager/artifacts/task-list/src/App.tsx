import { type FormEvent, type ReactNode, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  getGetTaskSummaryQueryKey,
  getListTasksQueryKey,
  useCreateTask,
  useDeleteTask,
  useGetTaskSummary,
  useListTasks,
  useUpdateTask,
} from '@workspace/api-client-react';
import type { ListTasksParams, Task, TaskInput, TaskPriority } from '@workspace/api-client-react';
import {
  AlertCircle,
  CalendarDays,
  Check,
  CheckCheck,
  CircleCheck,
  ClipboardList,
  Clock3,
  ListTodo,
  LoaderCircle,
  Plus,
  Search,
  Sparkles,
  Tag,
  Trash2,
  X,
  Pencil,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 15_000, refetchOnWindowFocus: false } },
});

type StatusFilter = NonNullable<ListTasksParams['status']>;
type PriorityFilter = NonNullable<ListTasksParams['priority']>;

const statusTabs: { value: StatusFilter; label: string }[] = [
  { value: 'all', label: 'Все дела' },
  { value: 'open', label: 'В работе' },
  { value: 'completed', label: 'Готово' },
  { value: 'overdue', label: 'Просрочено' },
];

const priorityLabels: Record<TaskPriority, string> = {
  low: 'Низкий приоритет',
  medium: 'Обычный приоритет',
  high: 'Высокий приоритет',
};

const localDateKey = (date: Date) => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const todayKey = localDateKey(new Date());

function displayDate(dateString: string) {
  const date = new Date(`${dateString.slice(0, 10)}T12:00:00`);
  return new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short' }).format(date);
}

function shortError(error: unknown) {
  if (error instanceof Error && error.message) return error.message;
  return 'Что-то пошло не так. Попробуйте ещё раз.';
}

function Home() {
  const queryClientInstance = useQueryClient();
  const [status, setStatus] = useState<StatusFilter>('all');
  const [priority, setPriority] = useState<PriorityFilter | ''>('');
  const [search, setSearch] = useState('');
  const [editorTask, setEditorTask] = useState<Task | undefined | null>(null);
  const [deleteTask, setDeleteTask] = useState<Task | null>(null);
  const [actionError, setActionError] = useState('');

  const params = useMemo<ListTasksParams>(() => ({
    status,
    ...(priority ? { priority } : {}),
    ...(search.trim() ? { search: search.trim() } : {}),
  }), [status, priority, search]);

  const tasksQuery = useListTasks(params);
  const summaryQuery = useGetTaskSummary();
  const createMutation = useCreateTask();
  const updateMutation = useUpdateTask();
  const deleteMutation = useDeleteTask();
  const summary = summaryQuery.data;

  const refreshTaskData = () => {
    void queryClientInstance.invalidateQueries({ queryKey: getListTasksQueryKey() });
    void queryClientInstance.invalidateQueries({ queryKey: getGetTaskSummaryQueryKey() });
  };

  const saveTask = (values: TaskInput) => {
    setActionError('');
    if (editorTask) {
      updateMutation.mutate({ id: editorTask.id, data: values }, {
        onSuccess: () => {
          refreshTaskData();
          setEditorTask(null);
        },
        onError: (error) => setActionError(shortError(error)),
      });
    } else {
      createMutation.mutate({ data: values }, {
        onSuccess: () => {
          refreshTaskData();
          setEditorTask(null);
        },
        onError: (error) => setActionError(shortError(error)),
      });
    }
  };

  const toggleTask = (task: Task) => {
    updateMutation.mutate({ id: task.id, data: { completed: !task.completed } }, {
      onSuccess: refreshTaskData,
    });
  };

  const confirmDelete = () => {
    if (!deleteTask) return;
    setActionError('');
    deleteMutation.mutate({ id: deleteTask.id }, {
      onSuccess: () => {
        refreshTaskData();
        setDeleteTask(null);
      },
      onError: (error) => setActionError(shortError(error)),
    });
  };

  const openCreate = () => {
    setActionError('');
    createMutation.reset();
    setEditorTask(undefined);
  };

  const openEdit = (task: Task) => {
    setActionError('');
    updateMutation.reset();
    setEditorTask(task);
  };

  const filterTabs = statusTabs.map((tab) => ({
    ...tab,
    count: tab.value === 'all' ? summary?.total
      : tab.value === 'open' ? summary?.open
        : tab.value === 'completed' ? summary?.completed
          : summary?.overdue,
  }));

  const todayLabel = new Intl.DateTimeFormat('ru-RU', {
    weekday: 'long', day: 'numeric', month: 'long',
  }).format(new Date());

  return (
    <main className="app-shell">
      <div className="workspace">
        <header className="topline">
          <div className="brand">
            <div className="brand-mark" aria-hidden="true"><ListTodo size={21} strokeWidth={2.1} /></div>
            <div>
              <div className="brand-name">По полочкам</div>
              <div className="brand-caption">Ваше пространство для дел</div>
            </div>
          </div>
          <div className="date-stamp">{todayLabel}</div>
        </header>

        <section className="hero" aria-labelledby="page-title">
          <div>
            <div className="eyebrow">День за днём — в своём ритме</div>
            <h1 id="page-title">Всё важное — под рукой</h1>
            <p>Небольшие шаги складываются в большие результаты.</p>
          </div>
          <button type="button" className="button-primary" onClick={openCreate} data-testid="button-add-task">
            <Plus size={17} /> Добавить дело
          </button>
        </section>

        <section className="stats-grid" aria-label="Сводка по задачам">
          <StatCard label="Всего дел" value={summary?.total} foot="ваш общий список" icon={<ClipboardList size={15} />} />
          <StatCard label="Осталось" value={summary?.open} foot="всё по силам" icon={<ListTodo size={15} />} />
          <StatCard label="Завершено" value={summary?.completed} foot="уже позади" icon={<CheckCheck size={15} />} />
          <StatCard label="На сегодня" value={summary?.dueToday} foot={summary?.overdue ? `${summary.overdue} просрочено` : 'можно спокойно успеть'} icon={<Clock3 size={15} />} />
        </section>

        <section className="task-section" aria-labelledby="tasks-heading">
          <div className="section-head">
            <div className="section-title-row">
              <h2 className="section-title" id="tasks-heading">Ваш список</h2>
              <span className="result-count" data-testid="text-task-count">
                {tasksQuery.isLoading ? 'Загружаем…' : `${tasksQuery.data?.length ?? 0} ${taskWord(tasksQuery.data?.length ?? 0)}`}
              </span>
            </div>
            <div className="filters">
              <label className="search-wrap">
                <Search size={16} aria-hidden="true" />
                <input
                  type="search"
                  className="search-input"
                  placeholder="Найти дело…"
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  aria-label="Поиск по задачам"
                  data-testid="input-search-tasks"
                />
              </label>
              <label>
                <span className="sr-only">Приоритет</span>
                <select
                  className="select-input"
                  value={priority}
                  onChange={(event) => setPriority(event.target.value as PriorityFilter | '')}
                  aria-label="Фильтр по приоритету"
                  data-testid="select-priority-filter"
                >
                  <option value="">Любой приоритет</option>
                  <option value="high">Высокий</option>
                  <option value="medium">Обычный</option>
                  <option value="low">Низкий</option>
                </select>
              </label>
            </div>
            <div className="tabs" role="tablist" aria-label="Фильтр задач по статусу">
              {filterTabs.map((tab) => (
                <button
                  type="button"
                  role="tab"
                  aria-selected={status === tab.value}
                  className={`tab${status === tab.value ? ' active' : ''}`}
                  key={tab.value}
                  onClick={() => setStatus(tab.value)}
                  data-testid={`tab-filter-${tab.value}`}
                >
                  {tab.label}
                  {tab.count !== undefined && <span className="tab-count">{tab.count}</span>}
                </button>
              ))}
            </div>
          </div>

          {tasksQuery.isLoading ? (
            <div className="task-list loading-state" aria-label="Загрузка задач" data-testid="status-loading">
              <div className="skeleton-line" /><div className="skeleton-line" /><div className="skeleton-line" />
            </div>
          ) : tasksQuery.isError ? (
            <div className="error-state" role="alert" data-testid="status-load-error">
              <AlertCircle size={25} />
              <p>Не получилось загрузить список дел.</p>
              <button type="button" className="button-secondary" onClick={() => void tasksQuery.refetch()} data-testid="button-retry-tasks">Попробовать снова</button>
            </div>
          ) : tasksQuery.data?.length ? (
            <div className="task-list" aria-live="polite">
              {tasksQuery.data.map((task, index) => (
                <TaskRow
                  key={task.id}
                  task={task}
                  index={index}
                  onToggle={() => toggleTask(task)}
                  onEdit={() => openEdit(task)}
                  onDelete={() => { setActionError(''); deleteMutation.reset(); setDeleteTask(task); }}
                  busy={updateMutation.isPending}
                />
              ))}
            </div>
          ) : (
            <div className="empty-state" data-testid="status-empty-tasks">
              <div className="empty-illustration"><Sparkles size={23} /></div>
              <h3>{search || priority || status !== 'all' ? 'Ничего не нашлось' : 'Здесь пока тихо'}</h3>
              <p>
                {search || priority || status !== 'all'
                  ? 'Попробуйте изменить поиск или фильтры — возможно, дело просто прячется.'
                  : 'Добавьте первое дело, чтобы освободить место в голове и начать двигаться.'}
              </p>
              {search || priority || status !== 'all'
                ? <button type="button" className="button-secondary" onClick={() => { setSearch(''); setPriority(''); setStatus('all'); }} data-testid="button-clear-filters">Сбросить фильтры</button>
                : <button type="button" className="button-primary" onClick={openCreate} data-testid="button-empty-add"><Plus size={16} /> Добавить первое дело</button>}
            </div>
          )}
        </section>

        <div className="footer-note"><CircleCheck size={14} /> Не обязательно успеть всё. Важно видеть, что уже получилось.</div>
      </div>

      {editorTask !== null && (
        <TaskEditor
          task={editorTask}
          pending={createMutation.isPending || updateMutation.isPending}
          error={actionError}
          onClose={() => { setEditorTask(null); setActionError(''); }}
          onSave={saveTask}
        />
      )}
      {deleteTask && (
        <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !deleteMutation.isPending) setDeleteTask(null); }}>
          <section className="modal modal-small" role="alertdialog" aria-modal="true" aria-labelledby="delete-title" aria-describedby="delete-description">
            <div className="modal-head">
              <div>
                <h2 className="modal-title" id="delete-title">Удалить это дело?</h2>
                <p className="modal-subtitle" id="delete-description">«{deleteTask.title}» исчезнет из списка без возможности восстановления.</p>
              </div>
              <button type="button" className="icon-button" aria-label="Закрыть" onClick={() => setDeleteTask(null)} data-testid="button-close-delete"><X size={17} /></button>
            </div>
            {actionError && <p className="notice" role="alert">{actionError}</p>}
            <div className="form-footer">
              <button type="button" className="button-secondary" onClick={() => setDeleteTask(null)} disabled={deleteMutation.isPending} data-testid="button-cancel-delete">Оставить</button>
              <button type="button" className="button-primary" style={{ background: 'hsl(var(--destructive))' }} onClick={confirmDelete} disabled={deleteMutation.isPending} data-testid="button-confirm-delete">
                {deleteMutation.isPending ? <LoaderCircle size={15} className="spin" /> : <Trash2 size={15} />}
                Удалить
              </button>
            </div>
          </section>
        </div>
      )}
    </main>
  );
}

function taskWord(count: number) {
  const mod10 = count % 10;
  const mod100 = count % 100;
  if (mod10 === 1 && mod100 !== 11) return 'дело';
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return 'дела';
  return 'дел';
}

function StatCard({ label, value, foot, icon }: { label: string; value?: number; foot: string; icon: ReactNode }) {
  return (
    <div className="stat-card" data-testid={`stat-${label.toLowerCase().replaceAll(' ', '-')}`}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 6 }}>
        <span className="stat-label">{label}</span>
        <span style={{ opacity: .62, display: 'inline-flex' }}>{icon}</span>
      </div>
      <div className="stat-value" aria-label={`${label}: ${value ?? 'загрузка'}`}>{value ?? '—'}</div>
      <div className="stat-foot">{foot}</div>
    </div>
  );
}

function TaskRow({ task, index, onToggle, onEdit, onDelete, busy }: {
  task: Task; index: number; onToggle: () => void; onEdit: () => void; onDelete: () => void; busy: boolean;
}) {
  const overdue = !task.completed && !!task.dueDate && task.dueDate.slice(0, 10) < todayKey;
  return (
    <article className="task-row" style={{ animationDelay: `${Math.min(index, 8) * 35}ms` }} data-testid={`task-row-${task.id}`}>
      <button
        type="button"
        className={`check-button${task.completed ? ' done' : ''}`}
        aria-label={task.completed ? `Вернуть в работу: ${task.title}` : `Отметить выполненным: ${task.title}`}
        aria-pressed={task.completed}
        onClick={onToggle}
        disabled={busy}
        data-testid={`button-complete-task-${task.id}`}
      >
        {task.completed && <Check size={14} strokeWidth={2.8} />}
      </button>
      <div className="task-main">
        <h3 className={`task-title${task.completed ? ' completed' : ''}`} data-testid={`text-task-title-${task.id}`}>{task.title}</h3>
        {task.details && <p className="task-details">{task.details}</p>}
        <div className="task-meta">
          <span className={`meta-chip priority ${task.priority}`} title="Приоритет">{priorityLabels[task.priority]}</span>
          {task.category && <span className="meta-chip"><Tag size={11} />{task.category}</span>}
          {task.dueDate && (
            <span className={`meta-chip due-chip${overdue ? ' overdue' : ''}`} data-testid={`text-due-date-${task.id}`}>
              <CalendarDays size={11} />{overdue ? 'Просрочено · ' : 'До '}{displayDate(task.dueDate)}
            </span>
          )}
        </div>
      </div>
      <div className="task-actions">
        <button type="button" className="icon-button" aria-label={`Изменить: ${task.title}`} onClick={onEdit} data-testid={`button-edit-task-${task.id}`}><Pencil size={15} /></button>
        <button type="button" className="icon-button" aria-label={`Удалить: ${task.title}`} onClick={onDelete} data-testid={`button-delete-task-${task.id}`}><Trash2 size={15} /></button>
      </div>
    </article>
  );
}

function TaskEditor({ task, pending, error, onClose, onSave }: {
  task: Task | undefined; pending: boolean; error: string; onClose: () => void; onSave: (data: TaskInput) => void;
}) {
  const [title, setTitle] = useState(task?.title ?? '');
  const [details, setDetails] = useState(task?.details ?? '');
  const [priority, setPriority] = useState<TaskPriority>(task?.priority ?? 'medium');
  const [category, setCategory] = useState(task?.category ?? '');
  const [dueDate, setDueDate] = useState(task?.dueDate?.slice(0, 10) ?? '');
  const [validationError, setValidationError] = useState('');

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const cleanTitle = title.trim();
    if (!cleanTitle) {
      setValidationError('Добавьте короткое название — так дело точно не потеряется.');
      return;
    }
    if (cleanTitle.length > 180) {
      setValidationError('Название должно быть не длиннее 180 символов.');
      return;
    }
    setValidationError('');
    onSave({
      title: cleanTitle,
      details: details.trim() || null,
      priority,
      category: category.trim() || null,
      dueDate: dueDate || null,
    });
  };

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !pending) onClose(); }}>
      <section className="modal" role="dialog" aria-modal="true" aria-labelledby="editor-title">
        <div className="modal-head">
          <div>
            <h2 className="modal-title" id="editor-title">{task ? 'Поправить дело' : 'Новое дело'}</h2>
            <p className="modal-subtitle">{task ? 'Измените детали, если планы сдвинулись.' : 'Запишите, чтобы не держать в голове.'}</p>
          </div>
          <button type="button" className="icon-button" aria-label="Закрыть форму" onClick={onClose} disabled={pending} data-testid="button-close-editor"><X size={17} /></button>
        </div>
        <form onSubmit={submit}>
          <div className="form-grid">
            <div className="field full">
              <label htmlFor="task-title">Что нужно сделать? <span className="field-hint">обязательно</span></label>
              <input id="task-title" className="form-input" maxLength={180} autoFocus value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Например, отправить документы" data-testid="input-task-title" />
            </div>
            <div className="field full">
              <label htmlFor="task-details">Подробности <span className="field-hint">если нужно</span></label>
              <textarea id="task-details" className="form-textarea" maxLength={2000} value={details} onChange={(event) => setDetails(event.target.value)} placeholder="Добавьте пару важных мыслей…" data-testid="input-task-details" />
            </div>
            <div className="field">
              <label htmlFor="task-priority">Приоритет</label>
              <select id="task-priority" className="form-input" value={priority} onChange={(event) => setPriority(event.target.value as TaskPriority)} data-testid="select-task-priority">
                <option value="low">Низкий</option><option value="medium">Обычный</option><option value="high">Высокий</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="task-date">Срок</label>
              <input id="task-date" type="date" className="form-input" value={dueDate} onChange={(event) => setDueDate(event.target.value)} data-testid="input-task-due-date" />
            </div>
            <div className="field full">
              <label htmlFor="task-category">Категория <span className="field-hint">например, «Дом» или «Работа»</span></label>
              <input id="task-category" className="form-input" maxLength={60} value={category} onChange={(event) => setCategory(event.target.value)} placeholder="Без категории" data-testid="input-task-category" />
            </div>
          </div>
          {(validationError || error) && <p className="notice" role="alert">{validationError || error}</p>}
          <div className="form-footer">
            <button type="button" className="button-secondary" onClick={onClose} disabled={pending} data-testid="button-cancel-editor">Отмена</button>
            <button type="submit" className="button-primary" disabled={pending} data-testid="button-save-task">
              {pending ? <LoaderCircle size={15} className="spin" /> : <Check size={15} />}
              {task ? 'Сохранить' : 'Добавить дело'}
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
