import { Router, type IRouter } from "express";

const FLASK_API_URL = "http://127.0.0.1:5001";

export function createTaskProxy(): IRouter {
  const router: IRouter = Router();

  router.use(async (req, res) => {
    try {
      const flaskPath = req.originalUrl.replace(/^\/api/, "");
      const upstreamUrl = new URL(flaskPath, FLASK_API_URL);
      const hasBody = req.method !== "GET" && req.method !== "HEAD";
      const upstream = await fetch(upstreamUrl, {
        method: req.method,
        headers: hasBody ? { "content-type": "application/json" } : undefined,
        body: hasBody ? JSON.stringify(req.body ?? {}) : undefined,
      });

      res.status(upstream.status);
      const contentType = upstream.headers.get("content-type");
      if (contentType) {
        res.setHeader("content-type", contentType);
      }

      if (upstream.status === 204) {
        res.end();
        return;
      }

      res.send(await upstream.text());
    } catch (err) {
      req.log.error({ err }, "Flask task API request failed");
      res.status(502).json({ error: "Сервер задач временно недоступен" });
    }
  });

  return router;
}
