import { spawn, type ChildProcess } from "node:child_process";
import path from "node:path";
import app from "./app";
import { logger } from "./lib/logger";

const workspaceRoot = path.resolve(process.cwd(), "../..");
const flaskBackend = path.join(workspaceRoot, "artifacts", "task-list", "backend");
const flaskExecutable = path.join(
  workspaceRoot,
  ".pythonlibs",
  "bin",
  process.env.NODE_ENV === "production" ? "gunicorn" : "python",
);
const flaskArgs =
  process.env.NODE_ENV === "production"
    ? [
        "--bind",
        "127.0.0.1:5001",
        "--workers",
        "2",
        "--access-logfile",
        "-",
        "--error-logfile",
        "-",
        "app:app",
      ]
    : [path.join(flaskBackend, "app.py")];

const flaskProcess: ChildProcess = spawn(flaskExecutable, flaskArgs, {
  cwd: flaskBackend,
  env: { ...process.env, PORT: "5001" },
  stdio: "inherit",
});

let isShuttingDown = false;
let stopServer: (() => void) | undefined;

flaskProcess.on("error", (err) => {
  logger.error({ err }, "Unable to start the Flask task API");
  process.exitCode = 1;
});

flaskProcess.on("exit", (code, signal) => {
  if (!isShuttingDown) {
    logger.error({ code, signal }, "Flask task API stopped unexpectedly");
    process.exitCode = 1;
  }
});

for (const signal of ["SIGINT", "SIGTERM"] as const) {
  process.on(signal, () => {
    isShuttingDown = true;
    flaskProcess.kill(signal);
    if (stopServer) {
      stopServer();
    } else {
      process.exit(0);
    }
  });
}

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

async function waitForFlask(): Promise<void> {
  const healthUrl = "http://127.0.0.1:5001/healthz";
  const deadline = Date.now() + 15_000;

  while (Date.now() < deadline) {
    try {
      const response = await fetch(healthUrl);
      if (response.ok) return;
    } catch {
      await new Promise((resolve) => setTimeout(resolve, 250));
    }
  }

  throw new Error("Flask task API did not start within 15 seconds.");
}

async function start(): Promise<void> {
  try {
    await waitForFlask();
  } catch (err) {
    logger.error({ err }, "Flask task API failed to become ready");
    flaskProcess.kill("SIGTERM");
    process.exit(1);
  }

  const server = app.listen(port, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      process.exit(1);
    }

    logger.info({ port }, "Server listening");
  });
  stopServer = () => {
    server.close(() => process.exit(0));
  };
}

void start();
