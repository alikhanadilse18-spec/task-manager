import {
  boolean,
  date,
  index,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const tasksTable = pgTable(
  "tasks",
  {
    id: serial("id").primaryKey(),
    title: text("title").notNull(),
    details: text("details"),
    priority: text("priority").notNull().default("medium"),
    category: text("category"),
    dueDate: date("due_date", { mode: "string" }),
    completed: boolean("completed").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true, mode: "string" })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true, mode: "string" })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("tasks_completed_due_date_idx").on(table.completed, table.dueDate),
    index("tasks_created_at_idx").on(table.createdAt),
  ],
);
