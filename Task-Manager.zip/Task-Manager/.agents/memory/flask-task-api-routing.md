---
name: Flask task API routing
description: Why the task app's Flask API is exposed through the shared API service.
---

Keep task CRUD and PostgreSQL access in Flask. The React app reaches it through the existing shared `/api` service, which forwards `/api/tasks` requests to the internal Flask process.

**Why:** The shared API artifact already owns the `/api` preview route, while the task app must retain its requested Flask backend.

**How to apply:** When adding task endpoints, update the Flask routes and keep the shared proxy forwarding the same `/api` contract unless service routing is deliberately changed.
